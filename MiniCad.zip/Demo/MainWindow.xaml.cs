﻿using Microsoft.Win32;
using MiniCad;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Demo
{
    public class Brush2
    {
        public string Name { get; set; }
        public Brush Value { get; set; }
    }

    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        #region -- Property changed --

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        #endregion

        private ObservableCollection<Brush2> _shapeStroke = new ObservableCollection<Brush2>(typeof(Colors).GetProperties().Select(x => new Brush2() { Name = x.Name, Value = new SolidColorBrush((Color)ColorConverter.ConvertFromString(x.Name)) }).ToList());

        public ObservableCollection<Brush2> ShapeStroke
        {
            get { return _shapeStroke; }
            set { _shapeStroke = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Brush2> _thumbStroke = new ObservableCollection<Brush2>(typeof(Colors).GetProperties().Select(x => new Brush2() { Name = x.Name, Value = new SolidColorBrush((Color)ColorConverter.ConvertFromString(x.Name)) }).ToList());

        public ObservableCollection<Brush2> ThumbStroke
        {
            get { return _thumbStroke; }
            set { _thumbStroke = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Brush2> _thumbFill = new ObservableCollection<Brush2>(typeof(Colors).GetProperties().Select(x => new Brush2() { Name = x.Name, Value = new SolidColorBrush((Color)ColorConverter.ConvertFromString(x.Name)) }).ToList());

        public ObservableCollection<Brush2> ThumbFill
        {
            get { return _thumbFill; }
            set { _thumbFill = value; OnPropertyChanged(); }
        }


        public MainWindow()
        {
            InitializeComponent();
        }

        private void Import_Image(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog() { Filter = "Image file | *.png;*.jpeg;*.jpg;*.bmp" };

            if (ofd.ShowDialog() == true)
            {
                drawingControl.ArtboardImage = new BitmapImage(new System.Uri(ofd.FileName));
            }
        }

        private void PantoCenter(object sender, RoutedEventArgs e)
        {
            drawingControl.PanToCenter();
        }

        private void ZoomToUniform(object sender, RoutedEventArgs e)
        {
            drawingControl.ZoomToUniform();
        }

        private void DrawingControl_ArtboardSizeChanged(object sender, SizeChangedEventArgs e)
        {
            drawingControl.PanToCenter();
            drawingControl.ZoomToUniform();
        }

        private void DrawingControl_ArtboardImageChanged(object sender, ImageChangedEventArgs e)
        {
            drawingControl.PanToCenter();
            drawingControl.ZoomToUniform();
        }

        private void ToolButton_Checked(object sender, RoutedEventArgs e)
        {
            var radioButton = (RadioButton)sender;
            switch (radioButton.Content.ToString())
            {
                case "Pan":
                    drawingControl.SelectedTool = DrawingTool.PanAndZoom;
                    break;
                case "Editor":
                    drawingControl.SelectedTool = DrawingTool.Edit;
                    break;
                case "Line":
                    drawingControl.SelectedTool = DrawingTool.Line;
                    break;
                case "Polyline":
                    drawingControl.SelectedTool = DrawingTool.Polyline;
                    break;
                case "Polygon":
                    drawingControl.SelectedTool = DrawingTool.Polygon;
                    break;
                case "Rectangle":
                    drawingControl.SelectedTool = DrawingTool.Rectangle;
                    break;
                case "Ellipse":
                    drawingControl.SelectedTool = DrawingTool.Ellipse;
                    break;
                case "Crop":
                    drawingControl.SelectedTool = DrawingTool.Crop;
                    break;
                default:
                    drawingControl.SelectedTool = DrawingTool.None;
                    break;
            }
        }

        private void AddShape_Click(object sender, RoutedEventArgs e)
        {
            Random rd = new Random();
            drawingControl.AddShape(new Line() 
            { 
                X1 = rd.Next(100, 900), 
                Y1 = rd.Next(100, 600),
                X2 = rd.Next(100, 900),
                Y2 = rd.Next(100, 600),
            });
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            drawingControl.ClearAll();
        }

        private void RemoveAllShapes_Click(object sender, RoutedEventArgs e)
        {
            drawingControl.RemoveAllShapes();
        }

        private void RemoveShape_Click(object sender, RoutedEventArgs e)
        {
            drawingControl.RemoveShape(drawingControl.SelectedShape);
        }
    }
}
